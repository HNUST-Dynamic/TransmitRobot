#include "screen.h"
#include <string.h>

#define screen (0x3D << 1)  // I2C地址左移适应I2C标准

extern UART_HandleTypeDef huart6;


uint8_t QRcode[8];
void receive_orangepi()
{
    // 从 UART 接收来自香橙派的二维码数据，并存储到QRcode数组中
    HAL_UART_Receive(&huart6, QRcode, sizeof(QRcode), HAL_MAX_DELAY);
}

void screen_transmit()
{
    // 将二维码数据通过 I2C 发送到 OLED 屏幕上
    if (strlen((char*)QRcode) > 0)
    {
        HAL_I2C_Master_Transmit(&hi2c1, screen, QRcode, strlen((char*)QRcode), HAL_MAX_DELAY);
    }
}

int man()
{
    HAL_Init();
    // 初始化 UART 和 I2C
    // 初始化屏幕等

    while (1)
    {
        receive_orangepi();  // 接收二维码数据

    }
}
