/*
 * screen.h
 *
 *  Created on: Sep 9, 2024
 *      Author: HuYuHao
 */

#ifndef INC_SCREEN_H_
#define INC_SCREEN_H_

#include "i2c.h"
void receive_orangepi();
void screen_transmit();
int man();

extern char QR[8];
#endif /* INC_SCREEN_H_ */
